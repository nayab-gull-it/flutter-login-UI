package com.example.basic_ui_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
